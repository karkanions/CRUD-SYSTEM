using System;
using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity;
using System.Linq;

namespace DataAccess.DBEntities
{
    public partial class DataInput : DbContext
    {
        public DataInput()
            : base("name=DataInput")
        {
        }

        public virtual DbSet<CampaignPool> CampaignPool { get; set; }
        public virtual DbSet<Campaigns> Campaigns { get; set; }
        public virtual DbSet<CampaignType> CampaignType { get; set; }
        public virtual DbSet<CampaignWaves> CampaignWaves { get; set; }
        public virtual DbSet<Columns> Columns { get; set; }
        public virtual DbSet<Tables> Tables { get; set; }
        public virtual DbSet<TestingInput> TestingInput { get; set; }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Campaigns>()
                .HasMany(e => e.CampaignPool)
                .WithRequired(e => e.Campaigns)
                .HasForeignKey(e => e.CampaignId)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<Campaigns>()
                .HasMany(e => e.CampaignWaves)
                .WithOptional(e => e.Campaigns)
                .HasForeignKey(e => e.CampaignId);

            modelBuilder.Entity<CampaignType>()
                .HasMany(e => e.Campaigns)
                .WithRequired(e => e.CampaignType1)
                .HasForeignKey(e => e.CampaignType)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<CampaignWaves>()
                .HasMany(e => e.CampaignPool)
                .WithRequired(e => e.CampaignWaves)
                .HasForeignKey(e => e.WaveId)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<Tables>()
                .HasMany(e => e.Columns)
                .WithRequired(e => e.Tables)
                .HasForeignKey(e => e.TableID)
                .WillCascadeOnDelete(false);
        }
    }
}
