namespace DataAccess.DBEntities
{
    using System;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;

    [Table("Test.TestingInput")]
    public partial class TestingInput
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int ID { get; set; }

        [Required]
        [StringLength(50)]
        public string Name { get; set; }

        public int Test1 { get; set; }

        public int? Test2 { get; set; }

        [StringLength(50)]
        public string InsertedUser { get; set; }

        [Column(TypeName = "date")]
        public DateTime? InsertedDate { get; set; }

        [StringLength(50)]
        public string LastUpdateUser { get; set; }

        [Column(TypeName = "date")]
        public DateTime? LastUpdateDate { get; set; }
    }
}
